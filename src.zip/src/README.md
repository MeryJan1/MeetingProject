# MeetingProject
![Başlıksız Diyagram drawio (1)](https://github.com/MeryJan1/MeetingProject/assets/125815842/524cc740-a319-4310-ab77-920e9216992e)
